package com.ecommerce.admin.admin.Exception;

public class CategoryAllreadyExist extends RuntimeException{
}
